﻿using BookStoreAPI.Entities;
using Microsoft.EntityFrameworkCore;
namespace BookStoreAPI.Data
{
    public class DataContext:DbContext
    {
        public DataContext(DbContextOptions options ):base(options) 
        {
       
        }
       public virtual DbSet<Book> Books { get; set; }

        public async Task <List<Book>> sp_GetBookDetails()
        {
           return await Books.FromSqlRaw("EXECUTE [dbo].[GetBookDetails]").ToListAsync();
        }
        public async Task<List<Book>> sp_GetBookDetailsSortedByAuthorFisrt()
        {
            return await Books.FromSqlRaw("EXECUTE [dbo].[GetBookDetailsSortedByAuthorFirst]").ToListAsync();
        }
    }
}

