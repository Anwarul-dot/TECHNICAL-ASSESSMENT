﻿using BookStoreAPI.Entities;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace BookStoreAPI.Data
{
    public static class Seed
    {
        public static async Task SeedUsers(DataContext dataContext)
        {
            if (await dataContext.Books.AnyAsync()) return;
            var bookData = await System.IO.File.ReadAllTextAsync("Data/UserSeedData.json");
            var books = JsonSerializer.Deserialize<List<Book>>(bookData);

            foreach (var book in books)
            {
                dataContext.Books.Add(book);
            }
            try
            {
                await dataContext.SaveChangesAsync();
            }
            catch(Exception ex)
            {


            }
        }
    }
}
