﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BookStoreAPI.Migrations
{
    public partial class GetBook_StoredProcedure : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            string sp_GetBook = @"CREATE PROCEDURE [dbo].[GetBookDetails]
                                    AS BEGIN
                                    select Id, Publisher,Title,AuthorFirstName,AuthorLastName,Price from [dbo].[Books] order by Publisher, AuthorLastName,AuthorFirstName,Title
                                    END
                                    ";
            migrationBuilder.Sql(sp_GetBook);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            string sp_delete = "IF EXISTS (select * from dbo.sysobjects " +
                "where id = object_id(N'[dbo].[GetBookDetails]') " +
                "and OBJECTPROPERTY(id, N'IsProcedure') = 1) DROP PROCEDURE [dbo].[GetBookDetails] GO";
            migrationBuilder.Sql(sp_delete);
        }
    }
}
