﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BookStoreAPI.Migrations
{
    public partial class GetBookSortedByAuthorFirst : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            string sp_GetBook = @"CREATE PROCEDURE [dbo].[GetBookDetailsSortedByAuthorFirst]
                                    AS BEGIN
                                    select Id, Publisher,Title,AuthorFirstName,AuthorLastName,Price from [dbo].[Books] order by AuthorLastName,AuthorFirstName,Title
                                    END
                                    ";
            migrationBuilder.Sql(sp_GetBook);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            string sp_delete = "IF EXISTS (select * from dbo.sysobjects " +
                "where id = object_id(N'[dbo].[GetBookDetailsSortedByAuthorFirst]') " +
                "and OBJECTPROPERTY(id, N'IsProcedure') = 1) DROP PROCEDURE [dbo].[GetBookDetailsSortedByAuthorFirst] GO";
            migrationBuilder.Sql(sp_delete);
        }
    }
}
