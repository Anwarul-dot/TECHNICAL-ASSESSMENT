﻿using BookStoreAPI.Data;
using BookStoreAPI.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BookStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookDetailsWithSPController : ControllerBase
    {
        private readonly DataContext _dataContext;
        public BookDetailsWithSPController(DataContext dataContext)
        {
            this._dataContext = dataContext;
        }

        [HttpGet("GetBookListWithSP")]
        public async Task<ActionResult<IEnumerable<Book>>> GetBookListWithSP()
        {
            return  await  _dataContext.sp_GetBookDetails() ;
        }

        [HttpGet("GetBookByAuthorFirstWithSP")]
        public async Task<ActionResult<IEnumerable<Book>>> GetBookByAuthorFirstWithSP()
        {
            return await _dataContext.sp_GetBookDetailsSortedByAuthorFisrt();
        }   
    }
}
