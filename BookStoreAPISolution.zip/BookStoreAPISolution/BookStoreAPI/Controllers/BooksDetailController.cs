﻿using BookStoreAPI.Data;
using BookStoreAPI.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BookStoreAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksDetailController : ControllerBase
    {
          private readonly DataContext _dataContext;
            public BooksDetailController(DataContext dataContext)
            {
                this._dataContext = dataContext;
            }

          [HttpGet("GetBookList")]
          public async Task<ActionResult<IEnumerable<Book>>> GetBookList()
          {
                 return await _dataContext.Books.OrderBy(p=>p.Publisher)
                .ThenBy(l=>l.AuthorLastName)
                .ThenBy(f=>f.AuthorFirstName)
                .ThenBy(t=>t.Title).ToListAsync();
          }

        [HttpGet("GetBookByAuthorFirst")]
        public async Task<ActionResult<IEnumerable<Book>>> GetBookByAuthorFirst()
        {
            return await _dataContext.Books
           .OrderBy(l => l.AuthorLastName)
           .ThenBy(f => f.AuthorFirstName)
           .ThenBy(t => t.Title).ToListAsync();
        }

        [HttpGet("GetTotalBookPrice")]
        public async Task<ActionResult<string>> GetTotalBookPrice()
        {
            return "Total Price of all books" + ' ' + await _dataContext.Books.SumAsync(p => p.Price);
        }
    }
}
